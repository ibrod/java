public class Main {
    public static void main(String[] args) throws Exception {
        Interact it=new Interact();
        it.interactive_interface();
    }
}
