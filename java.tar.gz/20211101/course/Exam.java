package course;

import java.util.Random;

public class Exam {
    public static int getGrades() {
        return (int)(Math.random()*50+50);
    }
}
